alpha<-2
y<-runif(1000)
x<-alpha*tan(y*pi/alpha)
print(x)
mean(x)