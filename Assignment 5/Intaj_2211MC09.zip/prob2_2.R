alpha<-2
beta<-1
y<runif(1000)
x<-(-1 / beta) * log(1 - y^1/alpha)
print(x)



















































