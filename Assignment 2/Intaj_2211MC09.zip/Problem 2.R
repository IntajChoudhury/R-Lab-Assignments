# Problem 2

Name <- c("Intaj", "Dhruv", "Ashutosh", "Lucky", "Nanda")
Age <- c(23, 25, 24, 22, 23)
Height <- c( 6, 5.8, 6.5, 5.9, 5.5)
Weight <- c( 85, 74, 50, 95, 90)

df <- data.frame( Name, Age, Height, Weight)

print (df)